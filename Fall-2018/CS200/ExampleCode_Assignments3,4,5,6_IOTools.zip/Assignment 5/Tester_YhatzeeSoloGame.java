package Yahtzee_Assignment_3_4;

public class Tester_YhatzeeSoloGame 
{

	public static void main(String[] args) 
	{
		YahtzeeSoloGame test = new YahtzeeSoloGame();
		test.gameStart();
	}

}
