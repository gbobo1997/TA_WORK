// (c) Robert Carver 2018
//package HistogramDieInterface;

//import java.util.ArrayList;

public class histTester 
{
	public static void main(String[] args)
	{
		/*ArrayList<Integer> test = new ArrayList<Integer>();
		test.add(1);
		test.add(1);
		test.add(2);
		test.add(3);
		Histogram testGram = new Histogram(test,"This is a test");
		System.out.println(testGram.generateHistogramVert());*/
		HistInterface testing = new HistInterface();
		testing.startInterface();
		
	}
}
